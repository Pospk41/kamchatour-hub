import { useEmergency as useEmergencyContext } from '../contexts/EmergencyContext';

export const useEmergency = useEmergencyContext;