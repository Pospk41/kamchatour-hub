# Assets

Добавьте изображения, используемые в app.json:

- ./assets/images/icon.png — иконка приложения (1024x1024)
- ./assets/images/adaptive-icon.png — адаптивная иконка Android (1024x1024)
- ./assets/images/favicon.png — фавикон для web (64x64)
- ./assets/images/splash-icon.png — изображение для Splash

Пути уже настроены в app.json. Если файлов нет, сборка/запуск может завершиться ошибкой — добавьте заглушки до реальных изображений.
